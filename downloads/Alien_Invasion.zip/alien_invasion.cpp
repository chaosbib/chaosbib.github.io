//  ========================================================================
//  COSC363 Assignment 1
//
//
//  Written By:
//  Ariel Evangelista
//	aev35 - 62193622
//
//
//  This assignment used the Lab 2 (Cannon.cpp) as a skeleton
//  To take advantage of the cannon model that was allowed to be used
//  This also used a skybox textures provided in Lab 4
//  All other textures was downloaded from www.textures.com
//  ========================================================================


#include <iostream>
#include <fstream>
#include <climits>
#include <math.h> 
#include <GL/freeglut.h>
#include "loadBMP.h"
#include "loadTGA.h"
using namespace std;

#define GL_CLAMP_TO_EDGE 0x812F

//--Globals: ---------------------------------------------------------------
float *x, *y, *z;  //vertex coordinate arrays
int *t1, *t2, *t3; //triangles in Cannon
int nvrt, ntri;    //total number of vertices and triangles in Cannon

// Textures
GLuint txId[8];

//Camera parameters
// 0 = Free Look
// 1 = Ship Camera
// 2 = Special Camera

int cam_mode = 0;
float angle = -1.6,
eye_x = 300,
eye_z = 0,
look_x = eye_x + 100 * sin(angle),
look_z = eye_z - 100 * cos(angle),
look_y = 20;
float cam_hgt = 40;

// Free Camera
float free_angle = -1.6,
free_eyex = 300,
free_eyez = 0,
free_lookx = free_eyex + 100 * sin(free_angle),
free_lookz = free_eyez + 100 * cos(free_angle),
free_looky = 20,
free_hgt = 40;


// Firing Canon
float bx = 49.88, by = 36.5, bz = 0, air_time = 0;
int ball_speed = 5;
int fired = 0;
float fire_arm = 180;

// Ship
float orbit = 0;
float ship_hgt = 0;
int lift = 0;

// Robot Patrol
float walk = 0;
float walk_flag = 0;
float walk_path = 270;
float patrol_walk = 0;
float patrol_dead = 0;
float patrol_fall = 0;
float patrol_revive = 0;
int patrol_alive = 1;
int patrol_test = 0;

// Robot Worker
float worker_path = 0;
float worker_walk = 0;
int worker_flag = 0;
float worker_arms = 60;
float worker_object = 5;

// Human-Controlled Robot
float rx, rz, ry = 0, rangle = 90, player = 17, p_view = 0;
int p_flag = 0, jump = 0, p_light = 1, tpv = 0;
// HCR Walk
float hcr_walk = 0, hcr_walker = 0;
int hcr_walking = 0;


// --End of Globals---------------------------------------------------------


void loadTexture()
{

	glGenTextures(7, txId);
	// *** left ***
	glBindTexture(GL_TEXTURE_2D, txId[0]);
	loadTGA("skybox/left.tga");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

	// *** front ***
	glBindTexture(GL_TEXTURE_2D, txId[1]);
	loadTGA("skybox/front.tga");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

	// *** right ***
	glBindTexture(GL_TEXTURE_2D, txId[2]);
	loadTGA("skybox/right.tga");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

	// *** back ***
	glBindTexture(GL_TEXTURE_2D, txId[3]);
	loadTGA("skybox/back.tga");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

	// *** up ***
	glBindTexture(GL_TEXTURE_2D, txId[4]);
	loadTGA("skybox/up.tga");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

	// *** down ***
	glBindTexture(GL_TEXTURE_2D, txId[5]);
	loadTGA("skybox/down.tga");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

	glBindTexture(GL_TEXTURE_2D, txId[6]);
	loadBMP("floor.bmp");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	glBindTexture(GL_TEXTURE_2D, txId[7]);
	loadBMP("walls.bmp");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
}

void loadMeshFile(const char* fname)
{
	ifstream fp_in;
	int num, ne;

	fp_in.open(fname, ios::in);
	if (!fp_in.is_open())
	{
		cout << "Error opening mesh file" << endl;
		exit(1);
	}

	fp_in.ignore(INT_MAX, '\n');				//ignore first line
	fp_in >> nvrt >> ntri >> ne;			    // read number of vertices, polygons, edges

	x = new float[nvrt];                        //create arrays
	y = new float[nvrt];
	z = new float[nvrt];

	t1 = new int[ntri];
	t2 = new int[ntri];
	t3 = new int[ntri];

	for (int i = 0; i < nvrt; i++)                         //read vertex list 
		fp_in >> x[i] >> y[i] >> z[i];

	for (int i = 0; i < ntri; i++)                         //read polygon list 
	{
		fp_in >> num >> t1[i] >> t2[i] >> t3[i];
		if (num != 3)
		{
			cout << "ERROR: Polygon with index " << i << " is not a triangle." << endl;  //not a triangle!!
			exit(1);
		}
	}

	fp_in.close();
	cout << " File successfully read." << endl;
}

void normal(int tindx)
{
	float x1 = x[t1[tindx]], x2 = x[t2[tindx]], x3 = x[t3[tindx]];
	float y1 = y[t1[tindx]], y2 = y[t2[tindx]], y3 = y[t3[tindx]];
	float z1 = z[t1[tindx]], z2 = z[t2[tindx]], z3 = z[t3[tindx]];
	float nx, ny, nz;
	nx = y1 * (z2 - z3) + y2 * (z3 - z1) + y3 * (z1 - z2);
	ny = z1 * (x2 - x3) + z2 * (x3 - x1) + z3 * (x1 - x2);
	nz = x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2);
	glNormal3f(nx, ny, nz);
}

void skybox()
{
	glEnable(GL_TEXTURE_2D);

	// Left
	glBindTexture(GL_TEXTURE_2D, txId[3]);
	glBegin(GL_QUADS);
	glTexCoord2f(0, 0);		glVertex3f(-1000, -450, 1000);
	glTexCoord2f(1, 0);		glVertex3f(-1000, -450., -1000);
	glTexCoord2f(1, 1);		glVertex3f(-1000, 550., -1000);
	glTexCoord2f(0, 1);		glVertex3f(-1000, 550, 1000);
	glEnd();

	// Front
	glBindTexture(GL_TEXTURE_2D, txId[2]);
	glBegin(GL_QUADS);
	glTexCoord2f(0, 0);		glVertex3f(-1000, -450, -1000);
	glTexCoord2f(1, 0);		glVertex3f(1000, -450., -1000);
	glTexCoord2f(1, 1);		glVertex3f(1000, 550, -1000);
	glTexCoord2f(0, 1);		glVertex3f(-1000, 550, -1000);
	glEnd();

	// Right
	glBindTexture(GL_TEXTURE_2D, txId[1]);
	glBegin(GL_QUADS);
	glTexCoord2f(0, 0);		glVertex3f(1000, -450, -1000);
	glTexCoord2f(1, 0);		glVertex3f(1000, -450, 1000);
	glTexCoord2f(1, 1);		glVertex3f(1000, 550, 1000);
	glTexCoord2f(0, 1);		glVertex3f(1000, 550, -1000);
	glEnd();


	// Back
	glBindTexture(GL_TEXTURE_2D, txId[0]);
	glBegin(GL_QUADS);
	glTexCoord2f(0, 0);		glVertex3f(1000, -450, 1000);
	glTexCoord2f(1, 0);		glVertex3f(-1000, -450, 1000);
	glTexCoord2f(1, 1);		glVertex3f(-1000, 550, 1000);
	glTexCoord2f(0, 1);		glVertex3f(1000, 550, 1000);
	glEnd();

	// Top
	glBindTexture(GL_TEXTURE_2D, txId[4]);
	glBegin(GL_QUADS);
	glTexCoord2f(0, 0);		glVertex3f(-1000, 550, -1000);
	glTexCoord2f(1, 0);		glVertex3f(1000, 550, -1000);
	glTexCoord2f(1, 1);		glVertex3f(1000, 550, 1000);
	glTexCoord2f(0, 1);		glVertex3f(-1000, 550, 1000);
	glEnd();

	// Down
	glBindTexture(GL_TEXTURE_2D, txId[5]);
	glBegin(GL_QUADS);
	glTexCoord2f(0, 0);		glVertex3f(-1000, -450, 1000);
	glTexCoord2f(1, 0);		glVertex3f(1000, -450, 1000);
	glTexCoord2f(1, 1);		glVertex3f(1000, -450, -1000);
	glTexCoord2f(0, 1);		glVertex3f(-1000, -450, -1000);
	glEnd();
}

void drawCannon()
{
	float white[4] = { 1., 1., 1., 1. };
	float black[4] = { 0 };

	glMaterialfv(GL_FRONT, GL_SPECULAR, black);

	glPushMatrix();
	glColor3f(0.5, 0.5, 0.5);
	glTranslatef(-20, 30, 0);
	glRotatef(5, 0, 0, 1);
	glTranslatef(20, -30, 0);

	//Construct the object model here using triangles read from OFF file
	glBegin(GL_TRIANGLES);
	for (int tindx = 0; tindx < ntri; tindx++)
	{
		normal(tindx);
		glVertex3d(x[t1[tindx]], y[t1[tindx]], z[t1[tindx]]);
		glVertex3d(x[t2[tindx]], y[t2[tindx]], z[t2[tindx]]);
		glVertex3d(x[t3[tindx]], y[t3[tindx]], z[t3[tindx]]);
	}
	glEnd();
	glPopMatrix();

	glPushMatrix();
	//right base
	glColor3f(0.5, 0.3, 0);
	glTranslatef(-10, 5, 17);
	glScalef(80, 10, 6);
	glutSolidCube(1);
	glPopMatrix();

	glPushMatrix();
	//right support
	glColor3f(0.5, 0.3, 0);
	glTranslatef(-20, 25, 17);
	glScalef(40, 30, 6);
	glutSolidCube(1);
	glPopMatrix();

	glPushMatrix();
	//left base
	glColor3f(0.5, 0.3, 0);
	glTranslatef(-10, 5, -17);
	glScalef(80, 10, 6);
	glutSolidCube(1);
	glPopMatrix();

	glPushMatrix();
	//left support
	glColor3f(0.5, 0.3, 0);
	glTranslatef(-20, 25, -17);
	glScalef(40, 30, 6);
	glutSolidCube(1);
	glPopMatrix();

	glPushMatrix();
	//Cannon Ball!
	glColor3f(0, 0, 0);
	glTranslatef(bx, by, bz);
	glutSolidSphere(5, 36, 18);
	glPopMatrix();

	glMaterialfv(GL_FRONT, GL_SPECULAR, white);
}

void drawCannonShadow()
{
	float white[4] = { 1., 1., 1., 1. };
	float black[4] = { 0 };

	glMaterialfv(GL_FRONT, GL_SPECULAR, black);

	glPushMatrix();
	glColor3f(0, 0, 0);
	glTranslatef(-20, 30, 0);
	glRotatef(5, 0, 0, 1);
	glTranslatef(20, -30, 0);

	//Construct the object model here using triangles read from OFF file
	glBegin(GL_TRIANGLES);
	for (int tindx = 0; tindx < ntri; tindx++)
	{
		normal(tindx);
		glVertex3d(x[t1[tindx]], y[t1[tindx]], z[t1[tindx]]);
		glVertex3d(x[t2[tindx]], y[t2[tindx]], z[t2[tindx]]);
		glVertex3d(x[t3[tindx]], y[t3[tindx]], z[t3[tindx]]);
	}
	glEnd();
	glPopMatrix();

	glPushMatrix();
	//right base
	glTranslatef(-10, 5, 17);
	glScalef(80, 10, 6);
	glutSolidCube(1);
	glPopMatrix();

	glPushMatrix();
	//right support
	glTranslatef(-20, 25, 17);
	glScalef(40, 30, 6);
	glutSolidCube(1);
	glPopMatrix();

	glPushMatrix();
	//left base
	glTranslatef(-10, 5, -17);
	glScalef(80, 10, 6);
	glutSolidCube(1);
	glPopMatrix();

	glPushMatrix();
	//left support
	glTranslatef(-20, 25, -17);
	glScalef(40, 30, 6);
	glutSolidCube(1);
	glPopMatrix();

	glPushMatrix();
	//Cannon Ball!
	glTranslatef(bx, by, bz);
	glutSolidSphere(5, 36, 18);
	glPopMatrix();

	glMaterialfv(GL_FRONT, GL_SPECULAR, white);
}

void drawFloor()
{

	float white[4] = { 1., 1., 1., 1. };
	float black[4] = { 0 };

	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, txId[6]);

	glColor4f(1., 1., 1., 1.0);
	glColor3f(0.8, 0.7, 0.5);
	glNormal3f(0.0, 1.0, 0.0);

	glMaterialfv(GL_FRONT, GL_SPECULAR, black);

	glBegin(GL_QUADS);
	// Inner floor with smaller tiles
	for (int i = -300; i < 300; i += 2)
	{
		for (int j = -300; j < 300; j += 2)
		{
			glVertex3f(i, 0, j);			//	0,0
			glVertex3f(i, 0, j + 2);		//	0,1
			glVertex3f(i + 2, 0, j + 2);	//	1,1
			glVertex3f(i + 2, 0, j);		//	1,0

		}
	}

	glColor3f(1., 1., 1.);
	for (int i = -600; i < 600; i += 50)
	{
		for (int j = -600; j < -300; j += 50)
		{
			glTexCoord2f(0, 0);	 glVertex3f(i, 0, j);			//	0,0
			glTexCoord2f(0, 1);	 glVertex3f(i, 0, j + 50);		//	0,1
			glTexCoord2f(1, 1);	 glVertex3f(i + 50, 0, j + 50);	//	1,1
			glTexCoord2f(1, 0);	 glVertex3f(i + 50, 0, j);		//	1,0
		}
	}
	for (int i = -600; i < 600; i += 50)
	{
		for (int j = 300; j < 600; j += 50)
		{
			glTexCoord2f(0, 0);	 glVertex3f(i, 0, j);			//	0,0
			glTexCoord2f(0, 1);	 glVertex3f(i, 0, j + 50);		//	0,1
			glTexCoord2f(1, 1);	 glVertex3f(i + 50, 0, j + 50);	//	1,1
			glTexCoord2f(1, 0);	 glVertex3f(i + 50, 0, j);		//	1,0
		}
	}

	for (int i = 300; i < 600; i += 50)
	{
		for (int j = -300; j < 300; j += 50)
		{
			glTexCoord2f(0, 0);	 glVertex3f(i, 0, j);			//	0,0
			glTexCoord2f(0, 1);	 glVertex3f(i, 0, j + 50);		//	0,1
			glTexCoord2f(1, 1);	 glVertex3f(i + 50, 0, j + 50);	//	1,1
			glTexCoord2f(1, 0);	 glVertex3f(i + 50, 0, j);		//	1,0
		}
	}

	for (int i = -600; i < -300; i += 50)
	{
		for (int j = -300; j < 300; j += 50)
		{
			glTexCoord2f(0, 0);	 glVertex3f(i, 0, j);			//	0,0
			glTexCoord2f(0, 1);	 glVertex3f(i, 0, j + 50);		//	0,1
			glTexCoord2f(1, 1);	 glVertex3f(i + 50, 0, j + 50);	//	1,1
			glTexCoord2f(1, 0);	 glVertex3f(i + 50, 0, j);		//	1,0
		}
	}

	/*
	glTexCoord2f(0, 0);	 glVertex3f(-600, 0, -600);		//	0,0
	glTexCoord2f(0, 1);	 glVertex3f(-600, 0, -300);		//	0,1
	glTexCoord2f(1, 1);	 glVertex3f(-300, 0, -300);		//	1,1
	glTexCoord2f(1, 0);	 glVertex3f(-300, 0, -600);		//	1,0
	*/
	glEnd();

	glMaterialfv(GL_FRONT, GL_SPECULAR, white);

	glDisable(GL_TEXTURE_2D);
}

void drawWalls()
{

	float white[4] = { 1., 1., 1., 1. };
	float black[4] = { 0 };

	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, txId[7]);

	//glColor3f(1., 1., 1.);

	glMaterialfv(GL_FRONT, GL_SPECULAR, black);

	// Front
	glPushMatrix();
	glTranslatef(200, 0, 0);
	glBegin(GL_QUADS);
	for (int i = 0; i < 100; i += 20)
	{
		for (int k = 0; k < 40; k += 20)
		{
			for (int j = -200; j < -60; j += 20)
			{
				if (i == 80 && k == 0) {
					glTexCoord2f(1, 0);	 glVertex3f(k, i + 20, j);			//	1 0
					glTexCoord2f(0, 0);	 glVertex3f(k, i + 20, j + 20);		//	0 0
					glTexCoord2f(0, 1);	 glVertex3f(k + 20, i + 20, j + 20);	//	0 1
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j);		//	1 1
				}

				if (j == -200 && k == 0) {
					glTexCoord2f(0, 0);	 glVertex3f(k, i, j);
					glTexCoord2f(1, 0);	 glVertex3f(k + 20, i, j);
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j);
					glTexCoord2f(0, 1);  glVertex3f(k, i + 20, j);
				}

				if (j == -80 && k == 0) {
					glTexCoord2f(0, 0);	 glVertex3f(k, i, j + 20);
					glTexCoord2f(1, 0);	 glVertex3f(k + 20, i, j + 20);
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j + 20);
					glTexCoord2f(0, 1);  glVertex3f(k, i + 20, j + 20);
				}

				glTexCoord2f(1, 0);	 glVertex3f(k, i, j);			//	1 0
				glTexCoord2f(0, 0);	 glVertex3f(k, i, j + 20);		//	0 0
				glTexCoord2f(0, 1);	 glVertex3f(k, i + 20, j + 20);	//	0 1
				glTexCoord2f(1, 1);	 glVertex3f(k, i + 20, j);		//	1 1
			}

			for (int j = -60; j < 60; j += 20) {
				if (i == 80 && k == 0) {
					glTexCoord2f(1, 0);	 glVertex3f(k, i + 20, j);			//	1 0
					glTexCoord2f(0, 0);	 glVertex3f(k, i + 20, j + 20);		//	0 0
					glTexCoord2f(0, 1);	 glVertex3f(k + 20, i + 20, j + 20);	//	0 1
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j);		//	1 1

					glTexCoord2f(1, 0);	 glVertex3f(k, i, j);			//	1 0
					glTexCoord2f(0, 0);	 glVertex3f(k, i, j + 20);		//	0 0
					glTexCoord2f(0, 1);	 glVertex3f(k + 20, i, j + 20);	//	0 1
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i, j);		//	1 1
				}
				if (i >= 80) {
					glTexCoord2f(1, 0);	 glVertex3f(k, i, j);			//	1 0
					glTexCoord2f(0, 0);	 glVertex3f(k, i, j + 20);		//	0 0
					glTexCoord2f(0, 1);	 glVertex3f(k, i + 20, j + 20);	//	0 1
					glTexCoord2f(1, 1);	 glVertex3f(k, i + 20, j);		//	1 1
				}
			}

			for (int j = 60; j < 200; j += 20)
			{
				if (i == 80 && k == 0) {
					glTexCoord2f(1, 0);	 glVertex3f(k, i + 20, j);			//	1 0
					glTexCoord2f(0, 0);	 glVertex3f(k, i + 20, j + 20);		//	0 0
					glTexCoord2f(0, 1);	 glVertex3f(k + 20, i + 20, j + 20);	//	0 1
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j);		//	1 1
				}

				if (j == 60 && k == 0) {
					glTexCoord2f(0, 0);	 glVertex3f(k, i, j);
					glTexCoord2f(1, 0);	 glVertex3f(k + 20, i, j);
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j);
					glTexCoord2f(0, 1);  glVertex3f(k, i + 20, j);
				}

				if (j == 180 && k == 0) {
					glTexCoord2f(0, 0);	 glVertex3f(k, i, j + 20);
					glTexCoord2f(1, 0);	 glVertex3f(k + 20, i, j + 20);
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j + 20);
					glTexCoord2f(0, 1);  glVertex3f(k, i + 20, j + 20);
				}

				glTexCoord2f(1, 0);	 glVertex3f(k, i, j);			//	1 0
				glTexCoord2f(0, 0);	 glVertex3f(k, i, j + 20);		//	0 0
				glTexCoord2f(0, 1);	 glVertex3f(k, i + 20, j + 20);	//	0 1
				glTexCoord2f(1, 1);	 glVertex3f(k, i + 20, j);		//	1 1
			}
		}
	}
	glEnd();
	glPopMatrix();

	// Right Front
	glPushMatrix();
	glTranslatef(30, 0, -250);
	glRotatef(70, 0, 1, 0);
	glBegin(GL_QUADS);
	for (int i = 0; i < 100; i += 20)
	{
		for (int k = 0; k < 40; k += 20)
		{
			for (int j = -200; j < 200; j += 20)
			{
				if (i == 80 && k == 0) {
					glTexCoord2f(1, 0);	 glVertex3f(k, i + 20, j);			//	1 0
					glTexCoord2f(0, 0);	 glVertex3f(k, i + 20, j + 20);		//	0 0
					glTexCoord2f(0, 1);	 glVertex3f(k + 20, i + 20, j + 20);	//	0 1
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j);		//	1 1
				}

				if (j == -200 && k == 0) {
					glTexCoord2f(0, 0);	 glVertex3f(k, i, j);
					glTexCoord2f(1, 0);	 glVertex3f(k + 20, i, j);
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j);
					glTexCoord2f(0, 1);  glVertex3f(k, i + 20, j);
				}

				if (j == 180 && k == 0) {
					glTexCoord2f(0, 0);	 glVertex3f(k, i, j + 20);
					glTexCoord2f(1, 0);	 glVertex3f(k + 20, i, j + 20);
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j + 20);
					glTexCoord2f(0, 1);  glVertex3f(k, i + 20, j + 20);
				}

				glTexCoord2f(1, 0);	 glVertex3f(k, i, j);			//	1 0
				glTexCoord2f(0, 0);	 glVertex3f(k, i, j + 20);		//	0 0
				glTexCoord2f(0, 1);	 glVertex3f(k, i + 20, j + 20);	//	0 1
				glTexCoord2f(1, 1);	 glVertex3f(k, i + 20, j);		//	1 1
			}
		}
	}
	glEnd();
	glPopMatrix();

	// Left Front
	glPushMatrix();
	glTranslatef(30, 0, 250);
	glRotatef(-70, 0, 1, 0);
	glBegin(GL_QUADS);
	for (int i = 0; i < 100; i += 20)
	{
		for (int k = 0; k < 40; k += 20)
		{
			for (int j = -200; j < 200; j += 20)
			{
				if (i == 80 && k == 0) {
					glTexCoord2f(1, 0);	 glVertex3f(k, i + 20, j);			//	1 0
					glTexCoord2f(0, 0);	 glVertex3f(k, i + 20, j + 20);		//	0 0
					glTexCoord2f(0, 1);	 glVertex3f(k + 20, i + 20, j + 20);	//	0 1
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j);		//	1 1
				}

				if (j == -200 && k == 0) {
					glTexCoord2f(0, 0);	 glVertex3f(k, i, j);
					glTexCoord2f(1, 0);	 glVertex3f(k + 20, i, j);
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j);
					glTexCoord2f(0, 1);  glVertex3f(k, i + 20, j);
				}

				if (j == 180 && k == 0) {
					glTexCoord2f(0, 0);	 glVertex3f(k, i, j + 20);
					glTexCoord2f(1, 0);	 glVertex3f(k + 20, i, j + 20);
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j + 20);
					glTexCoord2f(0, 1);  glVertex3f(k, i + 20, j + 20);
				}

				glTexCoord2f(1, 0);	 glVertex3f(k, i, j);			//	1 0
				glTexCoord2f(0, 0);	 glVertex3f(k, i, j + 20);		//	0 0
				glTexCoord2f(0, 1);	 glVertex3f(k, i + 20, j + 20);	//	0 1
				glTexCoord2f(1, 1);	 glVertex3f(k, i + 20, j);		//	1 1
			}
		}
	}
	glEnd();
	glPopMatrix();

	// Right Back
	glPushMatrix();
	glTranslatef(-260, 0, -165);
	glRotatef(140, 0, 1, 0);
	glBegin(GL_QUADS);
	for (int i = 0; i < 100; i += 20)
	{
		for (int k = 0; k < 40; k += 20)
		{
			for (int j = -220; j < 200; j += 20)
			{
				if (i == 80 && k == 0) {
					glTexCoord2f(1, 0);	 glVertex3f(k, i + 20, j);			//	1 0
					glTexCoord2f(0, 0);	 glVertex3f(k, i + 20, j + 20);		//	0 0
					glTexCoord2f(0, 1);	 glVertex3f(k + 20, i + 20, j + 20);	//	0 1
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j);		//	1 1
				}

				if (j == -220 && k == 0) {
					glTexCoord2f(0, 0);	 glVertex3f(k, i, j);
					glTexCoord2f(1, 0);	 glVertex3f(k + 20, i, j);
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j);
					glTexCoord2f(0, 1);  glVertex3f(k, i + 20, j);
				}

				if (j == 180 && k == 0) {
					glTexCoord2f(0, 0);	 glVertex3f(k, i, j + 20);
					glTexCoord2f(1, 0);	 glVertex3f(k + 20, i, j + 20);
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j + 20);
					glTexCoord2f(0, 1);  glVertex3f(k, i + 20, j + 20);
				}

				glTexCoord2f(1, 0);	 glVertex3f(k, i, j);			//	1 0
				glTexCoord2f(0, 0);	 glVertex3f(k, i, j + 20);		//	0 0
				glTexCoord2f(0, 1);	 glVertex3f(k, i + 20, j + 20);	//	0 1
				glTexCoord2f(1, 1);	 glVertex3f(k, i + 20, j);		//	1 1
			}
		}
	}
	glEnd();
	glPopMatrix();

	// Left Back
	glPushMatrix();
	glTranslatef(-260, 0, 165);
	glRotatef(-140, 0, 1, 0);
	glBegin(GL_QUADS);
	for (int i = 0; i < 100; i += 20)
	{
		for (int k = 0; k < 40; k += 20)
		{
			for (int j = -200; j < 220; j += 20)
			{
				if (i == 80 && k == 0) {
					glTexCoord2f(1, 0);	 glVertex3f(k, i + 20, j);			//	1 0
					glTexCoord2f(0, 0);	 glVertex3f(k, i + 20, j + 20);		//	0 0
					glTexCoord2f(0, 1);	 glVertex3f(k + 20, i + 20, j + 20);	//	0 1
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j);		//	1 1
				}

				if (j == -200 && k == 0) {
					glTexCoord2f(0, 0);	 glVertex3f(k, i, j);
					glTexCoord2f(1, 0);	 glVertex3f(k + 20, i, j);
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j);
					glTexCoord2f(0, 1);  glVertex3f(k, i + 20, j);
				}

				if (j == 200 && k == 0) {
					glTexCoord2f(0, 0);	 glVertex3f(k, i, j + 20);
					glTexCoord2f(1, 0);	 glVertex3f(k + 20, i, j + 20);
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j + 20);
					glTexCoord2f(0, 1);  glVertex3f(k, i + 20, j + 20);
				}

				glTexCoord2f(1, 0);	 glVertex3f(k, i, j);			//	1 0
				glTexCoord2f(0, 0);	 glVertex3f(k, i, j + 20);		//	0 0
				glTexCoord2f(0, 1);	 glVertex3f(k, i + 20, j + 20);	//	0 1
				glTexCoord2f(1, 1);	 glVertex3f(k, i + 20, j);		//	1 1
			}
		}
	}
	glEnd();
	glPopMatrix();

	glMaterialfv(GL_FRONT, GL_SPECULAR, white);

	glDisable(GL_TEXTURE_2D);
}

void drawPillars()
{
	float white[4] = { 1., 1., 1., 1. };
	float black[4] = { 0 };

	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, txId[7]);

	glMaterialfv(GL_FRONT, GL_SPECULAR, black);

	// Front Left Pillar
	glPushMatrix();
	glTranslatef(187.5, 0, 185);
	glBegin(GL_QUADS);
	for (int i = 0; i < 140; i += 20)
	{
		for (int k = 0; k < 40; k += 20)
		{
			for (int j = -20; j < 20; j += 20)
			{
				if (i == 80 && k < 40) {
					glTexCoord2f(1, 0);	 glVertex3f(k, i + 60, j);			//	1 0
					glTexCoord2f(0, 0);	 glVertex3f(k, i + 60, j + 20);		//	0 0
					glTexCoord2f(0, 1);	 glVertex3f(k + 20, i + 60, j + 20);	//	0 1
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 60, j);		//	1 1
				}

				if (j == -20 && k < 40) {
					glTexCoord2f(0, 0);	 glVertex3f(k, i, j);
					glTexCoord2f(1, 0);	 glVertex3f(k + 20, i, j);
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j);
					glTexCoord2f(0, 1);  glVertex3f(k, i + 20, j);
				}

				if (j == 0 && k < 40) {
					glTexCoord2f(0, 0);	 glVertex3f(k, i, j + 20);
					glTexCoord2f(1, 0);	 glVertex3f(k + 20, i, j + 20);
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j + 20);
					glTexCoord2f(0, 1);  glVertex3f(k, i + 20, j + 20);
				}

				int t = k;

				if (k == 20) t = k + 20;

				glTexCoord2f(1, 0);	 glVertex3f(t, i, j);			//	1 0
				glTexCoord2f(0, 0);	 glVertex3f(t, i, j + 20);		//	0 0
				glTexCoord2f(0, 1);	 glVertex3f(t, i + 20, j + 20);	//	0 1
				glTexCoord2f(1, 1);	 glVertex3f(t, i + 20, j);		//	1 1
			}
		}
	}
	glEnd();
	glPopMatrix();

	// Front Right Pillar
	glPushMatrix();
	glTranslatef(187.5, 0, -185);
	glBegin(GL_QUADS);
	for (int i = 0; i < 140; i += 20)
	{
		for (int k = 0; k < 40; k += 20)
		{
			for (int j = -20; j < 20; j += 20)
			{
				if (i == 80 && k < 40) {
					glTexCoord2f(1, 0);	 glVertex3f(k, i + 60, j);			//	1 0
					glTexCoord2f(0, 0);	 glVertex3f(k, i + 60, j + 20);		//	0 0
					glTexCoord2f(0, 1);	 glVertex3f(k + 20, i + 60, j + 20);	//	0 1
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 60, j);		//	1 1
				}

				if (j == -20 && k < 40) {
					glTexCoord2f(0, 0);	 glVertex3f(k, i, j);
					glTexCoord2f(1, 0);	 glVertex3f(k + 20, i, j);
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j);
					glTexCoord2f(0, 1);  glVertex3f(k, i + 20, j);
				}

				if (j == 0 && k < 40) {
					glTexCoord2f(0, 0);	 glVertex3f(k, i, j + 20);
					glTexCoord2f(1, 0);	 glVertex3f(k + 20, i, j + 20);
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j + 20);
					glTexCoord2f(0, 1);  glVertex3f(k, i + 20, j + 20);
				}

				int t = k;

				if (k == 20) t = k + 20;

				glTexCoord2f(1, 0);	 glVertex3f(t, i, j);			//	1 0
				glTexCoord2f(0, 0);	 glVertex3f(t, i, j + 20);		//	0 0
				glTexCoord2f(0, 1);	 glVertex3f(t, i + 20, j + 20);	//	0 1
				glTexCoord2f(1, 1);	 glVertex3f(t, i + 20, j);		//	1 1
			}
		}
	}
	glEnd();
	glPopMatrix();

	// Right Pillar
	glPushMatrix();
	glTranslatef(-160, 0, -317.5);
	glBegin(GL_QUADS);
	for (int i = 0; i < 140; i += 20)
	{
		for (int k = 0; k < 40; k += 20)
		{
			for (int j = -20; j < 20; j += 20)
			{
				if (i == 80 && k < 40) {
					glTexCoord2f(1, 0);	 glVertex3f(k, i + 60, j);			//	1 0
					glTexCoord2f(0, 0);	 glVertex3f(k, i + 60, j + 20);		//	0 0
					glTexCoord2f(0, 1);	 glVertex3f(k + 20, i + 60, j + 20);	//	0 1
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 60, j);		//	1 1
				}

				if (j == -20 && k < 40) {
					glTexCoord2f(0, 0);	 glVertex3f(k, i, j);
					glTexCoord2f(1, 0);	 glVertex3f(k + 20, i, j);
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j);
					glTexCoord2f(0, 1);  glVertex3f(k, i + 20, j);
				}

				if (j == 0 && k < 40) {
					glTexCoord2f(0, 0);	 glVertex3f(k, i, j + 20);
					glTexCoord2f(1, 0);	 glVertex3f(k + 20, i, j + 20);
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j + 20);
					glTexCoord2f(0, 1);  glVertex3f(k, i + 20, j + 20);
				}

				int t = k;

				if (k == 20) t = k + 20;

				glTexCoord2f(1, 0);	 glVertex3f(t, i, j);			//	1 0
				glTexCoord2f(0, 0);	 glVertex3f(t, i, j + 20);		//	0 0
				glTexCoord2f(0, 1);	 glVertex3f(t, i + 20, j + 20);	//	0 1
				glTexCoord2f(1, 1);	 glVertex3f(t, i + 20, j);		//	1 1
			}
		}
	}
	glEnd();
	glPopMatrix();

	// Left Pillar
	glPushMatrix();
	glTranslatef(-160, 0, 317.5);
	glBegin(GL_QUADS);
	for (int i = 0; i < 140; i += 20)
	{
		for (int k = 0; k < 40; k += 20)
		{
			for (int j = -20; j < 20; j += 20)
			{
				if (i == 80 && k < 40) {
					glTexCoord2f(1, 0);	 glVertex3f(k, i + 60, j);			//	1 0
					glTexCoord2f(0, 0);	 glVertex3f(k, i + 60, j + 20);		//	0 0
					glTexCoord2f(0, 1);	 glVertex3f(k + 20, i + 60, j + 20);	//	0 1
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 60, j);		//	1 1
				}

				if (j == -20 && k < 40) {
					glTexCoord2f(0, 0);	 glVertex3f(k, i, j);
					glTexCoord2f(1, 0);	 glVertex3f(k + 20, i, j);
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j);
					glTexCoord2f(0, 1);  glVertex3f(k, i + 20, j);
				}

				if (j == 0 && k < 40) {
					glTexCoord2f(0, 0);	 glVertex3f(k, i, j + 20);
					glTexCoord2f(1, 0);	 glVertex3f(k + 20, i, j + 20);
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j + 20);
					glTexCoord2f(0, 1);  glVertex3f(k, i + 20, j + 20);
				}

				int t = k;

				if (k == 20) t = k + 20;

				glTexCoord2f(1, 0);	 glVertex3f(t, i, j);			//	1 0
				glTexCoord2f(0, 0);	 glVertex3f(t, i, j + 20);		//	0 0
				glTexCoord2f(0, 1);	 glVertex3f(t, i + 20, j + 20);	//	0 1
				glTexCoord2f(1, 1);	 glVertex3f(t, i + 20, j);		//	1 1
			}
		}
	}
	glEnd();
	glPopMatrix();

	// Back Pillar
	glPushMatrix();
	glTranslatef(-417.5, 0, 0);
	glBegin(GL_QUADS);
	for (int i = 0; i < 140; i += 20)
	{
		for (int k = 0; k < 40; k += 20)
		{
			for (int j = -20; j < 20; j += 20)
			{
				if (i == 80 && k < 40) {
					glTexCoord2f(1, 0);	 glVertex3f(k, i + 60, j);			//	1 0
					glTexCoord2f(0, 0);	 glVertex3f(k, i + 60, j + 20);		//	0 0
					glTexCoord2f(0, 1);	 glVertex3f(k + 20, i + 60, j + 20);	//	0 1
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 60, j);		//	1 1
				}

				if (j == -20 && k < 40) {
					glTexCoord2f(0, 0);	 glVertex3f(k, i, j);
					glTexCoord2f(1, 0);	 glVertex3f(k + 20, i, j);
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j);
					glTexCoord2f(0, 1);  glVertex3f(k, i + 20, j);
				}

				if (j == 0 && k < 40) {
					glTexCoord2f(0, 0);	 glVertex3f(k, i, j + 20);
					glTexCoord2f(1, 0);	 glVertex3f(k + 20, i, j + 20);
					glTexCoord2f(1, 1);	 glVertex3f(k + 20, i + 20, j + 20);
					glTexCoord2f(0, 1);  glVertex3f(k, i + 20, j + 20);
				}

				int t = k;

				if (k == 20) t = k + 20;

				glTexCoord2f(1, 0);	 glVertex3f(t, i, j);			//	1 0
				glTexCoord2f(0, 0);	 glVertex3f(t, i, j + 20);		//	0 0
				glTexCoord2f(0, 1);	 glVertex3f(t, i + 20, j + 20);	//	0 1
				glTexCoord2f(1, 1);	 glVertex3f(t, i + 20, j);		//	1 1
			}
		}
	}
	glEnd();
	glPopMatrix();

	glMaterialfv(GL_FRONT, GL_SPECULAR, white);

	glDisable(GL_TEXTURE_2D);
}

void drawShip()
{
	glPushMatrix();
	glTranslatef(0, 40, 0);
	glColor3f(1, 0, 0);
	//Cockpit
	glPushMatrix();
	glScalef(1, 0.85, 1);
	glutSolidSphere(30, 50, 50);
	glPopMatrix();
	glColor3f(0, 0, 1);
	// orbits
	glPushMatrix();
	glRotatef(orbit, 1, 0, 0);
	glScalef(1.1, 1.1, 0.25);
	glutSolidTorus(1, 30, 10, 10);
	glPopMatrix();
	glPushMatrix();
	glRotatef(orbit, 0, 0, 1);
	glRotatef(90, 0, 1, 0);
	glScalef(1.1, 1.1, 0.25);
	glutSolidTorus(1, 30, 10, 10);
	glPopMatrix();
	glPushMatrix();
	glRotatef(-orbit, 1, 0, 0);
	glScalef(1.1, 1.1, 0.25);
	glutSolidTorus(1, 30, 10, 10);
	glPopMatrix();
	glPushMatrix();
	glRotatef(-orbit, 0, 0, 1);
	glRotatef(90, 0, 1, 0);
	glScalef(1.1, 1.1, 0.25);
	glutSolidTorus(1, 30, 10, 10);
	glPopMatrix();

	// base
	glRotatef(90, 1, 0, 0);
	glScalef(1, 1, 0.5);
	glColor3f(1, 1, 1);
	glTranslatef(0, 0, 15);
	glutSolidTorus(20, 30, 10, 10);
	glPopMatrix();
	glPushMatrix();
	glColor3f(1, 1, 0);
	glRotatef(90, 1, 0, 0);
	glScalef(1, 1, 0.5);
	glTranslatef(0, 0, -43);
	glutSolidTorus(10, 20, 10, 10);
	glPopMatrix();
}

void drawShipShadow()
{
	glPushMatrix();
	glTranslatef(0, 40, 0);
	glColor3f(0, 0, 0);
	//Cockpit
	glPushMatrix();
	glScalef(1, 0.85, 1);
	glutSolidSphere(30, 50, 50);
	glPopMatrix();

	// orbits
	glPushMatrix();
	glRotatef(orbit, 1, 0, 0);
	glScalef(1.1, 1.1, 0.25);
	glutSolidTorus(1, 30, 10, 10);
	glPopMatrix();
	glPushMatrix();
	glRotatef(orbit, 0, 0, 1);
	glRotatef(90, 0, 1, 0);
	glScalef(1.1, 1.1, 0.25);
	glutSolidTorus(1, 30, 10, 10);
	glPopMatrix();
	glPushMatrix();
	glRotatef(-orbit, 1, 0, 0);
	glScalef(1.1, 1.1, 0.25);
	glutSolidTorus(1, 30, 10, 10);
	glPopMatrix();
	glPushMatrix();
	glRotatef(-orbit, 0, 0, 1);
	glRotatef(90, 0, 1, 0);
	glScalef(1.1, 1.1, 0.25);
	glutSolidTorus(1, 30, 10, 10);
	glPopMatrix();

	// base
	glRotatef(90, 1, 0, 0);
	glScalef(1, 1, 0.5);
	glTranslatef(0, 0, 15);
	glutSolidTorus(20, 30, 10, 10);
	glPopMatrix();
	glPushMatrix();
	glRotatef(90, 1, 0, 0);
	glScalef(1, 1, 0.5);
	glTranslatef(0, 0, -43);
	glutSolidTorus(10, 20, 10, 10);
	glPopMatrix();
}

void drawRobot()
{
	glColor3f(.5, .5, .5);				// Antenna
	glPushMatrix();
	glTranslatef(0, 8.4, 0);
	glRotatef(-90, 1, 0, 0);
	glutSolidCone(0.3, 3, 6, 6);
	glPopMatrix();

	glColor3f(.5, .5, .5);				//Nose
	glPushMatrix();
	glTranslatef(0, 7.5, -0.7);
	glutSolidSphere(0.25, 8, 8);
	glPopMatrix();

	glColor3f(1, 0, 0);				//Right Eye
	glPushMatrix();
	glTranslatef(0.35, 8, -0.7);
	glutSolidSphere(0.15, 8, 8);
	glPopMatrix();

	glColor3f(1, 0, 0);				//Left Eye
	glPushMatrix();
	glTranslatef(-0.35, 8, -0.7);
	glutSolidSphere(0.15, 8, 8);
	glPopMatrix();

	glColor3f(0.5, 0.5, 0.5);		//Head
	glPushMatrix();
	glTranslatef(0, 7.7, 0);
	glutSolidCube(1.4);
	glPopMatrix();

	glColor3f(0.5, 0.5, 0.5);			//Torso
	glPushMatrix();
	glTranslatef(0, 5.5, 0);
	glScalef(3, 3, 1.4);
	glutSolidCube(1);
	glPopMatrix();

	glColor3f(0.5, 0.5, 0.5);			//Right leg
	glPushMatrix();
	glTranslatef(-0.8, 4, 0);
	glRotatef(-hcr_walk, 1, 0, 0);
	glTranslatef(0.8, -4, 0);
	glTranslatef(-0.8, 2.2, 0);
	glScalef(1, 4.4, 1);
	glutSolidCube(1);
	glPopMatrix();

	glColor3f(0.5, 0.5, 0.5);			//Left leg
	glPushMatrix();
	glTranslatef(0.8, 4, 0);
	glRotatef(hcr_walk, 1, 0, 0);
	glTranslatef(-0.8, -4, 0);
	glTranslatef(0.8, 2.2, 0);
	glScalef(1, 4.4, 1);
	glutSolidCube(1);
	glPopMatrix();

	glColor3f(0.5, 0.5, 0.5);			//Right arm
	glPushMatrix();
	glTranslatef(-2, 6.5, 0);
	glRotatef(hcr_walk, 1, 0, 0);
	glTranslatef(2, -6.5, 0);
	glTranslatef(-2, 5, 0);
	glScalef(1, 4, 1);
	glutSolidCube(1);
	glPopMatrix();

	glColor3f(0.5, 0.5, 0.5);			//Left arm
	glPushMatrix();
	glTranslatef(2, 6.5, 0);
	glRotatef(-hcr_walk, 1, 0, 0);
	glTranslatef(-2, -6.5, 0);
	glTranslatef(2, 5, 0);
	glScalef(1, 4, 1);
	glutSolidCube(1);
	glPopMatrix();
}

void drawRobotPatrol()
{
	glColor3f(.5, .5, .5);				// Antenna
	glPushMatrix();
	glTranslatef(0, 8.4, 0);
	glRotatef(-90, 1, 0, 0);
	glutSolidCone(0.3, 3, 6, 6);
	glPopMatrix();

	glColor3f(.5, .5, .5);				//Nose
	glPushMatrix();
	glTranslatef(0, 7.5, -0.7);
	glutSolidSphere(0.25, 8, 8);
	glPopMatrix();

	glColor3f(1, 0, 0);				//Right Eye
	glPushMatrix();
	glTranslatef(0.35, 8, -0.7);
	glutSolidSphere(0.15, 8, 8);
	glPopMatrix();

	glColor3f(1, 0, 0);				//Left Eye
	glPushMatrix();
	glTranslatef(-0.35, 8, -0.7);
	glutSolidSphere(0.15, 8, 8);
	glPopMatrix();

	glColor3f(0.5, 0.5, 0.5);		//Head
	glPushMatrix();
	glTranslatef(0, 7.7, 0);
	glutSolidCube(1.4);
	glPopMatrix();

	glColor3f(0.5, 0.5, 0.5);			//Torso
	glPushMatrix();
	glTranslatef(0, 5.5, 0);
	glScalef(3, 3, 1.4);
	glutSolidCube(1);
	glPopMatrix();

	glColor3f(0.5, 0.5, 0.5);			//Right leg
	glPushMatrix();
	glTranslatef(-0.8, 4, 0);
	glRotatef(-patrol_walk, 1, 0, 0);
	glTranslatef(0.8, -4, 0);
	glTranslatef(-0.8, 2.2, 0);
	glScalef(1, 4.4, 1);
	glutSolidCube(1);
	glPopMatrix();

	glColor3f(0.5, 0.5, 0.5);			//Left leg
	glPushMatrix();
	glTranslatef(0.8, 4, 0);
	glRotatef(patrol_walk, 1, 0, 0);
	glTranslatef(-0.8, -4, 0);
	glTranslatef(0.8, 2.2, 0);
	glScalef(1, 4.4, 1);
	glutSolidCube(1);
	glPopMatrix();

	glColor3f(0.5, 0.5, 0.5);			//Right arm
	glPushMatrix();
	glTranslatef(-2, 6.5, 0);
	glRotatef(patrol_walk, 1, 0, 0);
	glTranslatef(2, -6.5, 0);
	glTranslatef(-2, 5, 0);
	glScalef(1, 4, 1);
	glutSolidCube(1);
	glPopMatrix();

	glColor3f(0.5, 0.5, 0.5);			//Left arm
	glPushMatrix();
	glTranslatef(2, 6.5, 0);
	glRotatef(-patrol_walk, 1, 0, 0);
	glTranslatef(-2, -6.5, 0);
	glTranslatef(2, 5, 0);
	glScalef(1, 4, 1);
	glutSolidCube(1);
	glPopMatrix();
}

void drawRobotWorker()
{
	glColor3f(.5, .5, .5);				// Antenna
	glPushMatrix();
	glTranslatef(0, 8.4, 0);
	glRotatef(-90, 1, 0, 0);
	glutSolidCone(0.3, 3, 6, 6);
	glPopMatrix();

	glColor3f(.5, .5, .5);				//Nose
	glPushMatrix();
	glTranslatef(0, 7.5, -0.7);
	glutSolidSphere(0.25, 8, 8);
	glPopMatrix();

	glColor3f(1, 0, 0);				//Right Eye
	glPushMatrix();
	glTranslatef(0.35, 8, -0.7);
	glutSolidSphere(0.15, 8, 8);
	glPopMatrix();

	glColor3f(1, 0, 0);				//Left Eye
	glPushMatrix();
	glTranslatef(-0.35, 8, -0.7);
	glutSolidSphere(0.15, 8, 8);
	glPopMatrix();

	glColor3f(0.5, 0.5, 0.5);		//Head
	glPushMatrix();
	glTranslatef(0, 7.7, 0);
	glutSolidCube(1.4);
	glPopMatrix();

	glColor3f(0.5, 0.5, 0.5);			//Torso
	glPushMatrix();
	glTranslatef(0, 5.5, 0);
	glScalef(3, 3, 1.4);
	glutSolidCube(1);
	glPopMatrix();

	glColor3f(0.5, 0.5, 0.5);			//Right leg
	glPushMatrix();
	glTranslatef(-0.8, 4, 0);
	glRotatef(-worker_walk, 1, 0, 0);
	glTranslatef(0.8, -4, 0);
	glTranslatef(-0.8, 2.2, 0);
	glScalef(1, 4.4, 1);
	glutSolidCube(1);
	glPopMatrix();

	glColor3f(0.5, 0.5, 0.5);			//Left leg
	glPushMatrix();
	glTranslatef(0.8, 4, 0);
	glRotatef(worker_walk, 1, 0, 0);
	glTranslatef(-0.8, -4, 0);
	glTranslatef(0.8, 2.2, 0);
	glScalef(1, 4.4, 1);
	glutSolidCube(1);
	glPopMatrix();

	glColor3f(0.5, 0.5, 0.5);			//Right arm
	glPushMatrix();
	glTranslatef(-2, 6.5, 0);
	glRotatef(worker_arms, 1, 0, 0);
	glTranslatef(2, -6.5, 0);
	glTranslatef(-2, 5, 0);
	glScalef(1, 4, 1);
	glutSolidCube(1);
	glPopMatrix();

	glColor3f(0.5, 0.5, 0.5);		//Left arm
	glPushMatrix();
	glTranslatef(2, 6.5, 0);
	glRotatef(worker_arms, 1, 0, 0);
	glTranslatef(-2, -6.5, 0);
	glTranslatef(2, 5, 0);
	glScalef(1, 4, 1);
	glutSolidCube(1);
	glPopMatrix();
}

void drawRobotOperator()
{
	glColor3f(.5, .5, .5);				// Antenna
	glPushMatrix();
	glTranslatef(0, 8.4, 0);
	glRotatef(-90, 1, 0, 0);
	glutSolidCone(0.3, 3, 6, 6);
	glPopMatrix();

	glColor3f(.5, .5, .5);				//Nose
	glPushMatrix();
	glTranslatef(0, 7.5, -0.7);
	glutSolidSphere(0.25, 8, 8);
	glPopMatrix();

	glColor3f(1, 0, 0);				//Right Eye
	glPushMatrix();
	glTranslatef(0.35, 8, -0.7);
	glutSolidSphere(0.15, 8, 8);
	glPopMatrix();

	glColor3f(1, 0, 0);				//Left Eye
	glPushMatrix();
	glTranslatef(-0.35, 8, -0.7);
	glutSolidSphere(0.15, 8, 8);
	glPopMatrix();

	glColor3f(0.5, 0.5, 0.5);		//Head
	glPushMatrix();
	glTranslatef(0, 7.7, 0);
	glutSolidCube(1.4);
	glPopMatrix();

	glColor3f(0.5, 0.5, 0.5);			//Torso
	glPushMatrix();
	glTranslatef(0, 5.5, 0);
	glScalef(3, 3, 1.4);
	glutSolidCube(1);
	glPopMatrix();

	glColor3f(0.5, 0.5, 0.5);			//Right leg
	glPushMatrix();
	glTranslatef(-0.8, 2.2, 0);
	glScalef(1, 4.4, 1);
	glutSolidCube(1);
	glPopMatrix();

	glColor3f(0.5, 0.5, 0.5);			//Left leg
	glPushMatrix();
	glTranslatef(0.8, 2.2, 0);
	glScalef(1, 4.4, 1);
	glutSolidCube(1);
	glPopMatrix();

	glColor3f(0.5, 0.5, 0.5);			//Right arm
	glPushMatrix();
	glTranslatef(-2, 5, 0);
	glScalef(1, 4, 1);
	glutSolidCube(1);
	glPopMatrix();

	glColor3f(0.5, 0.5, 0.5);			//Left arm
	glPushMatrix();
	glTranslatef(2, 6.5, 0);
	glRotatef(fire_arm, 1, 0, 0);
	glTranslatef(-2, -6.5, 0);
	glTranslatef(2, 5, 0);
	glScalef(1, 4, 1);
	glutSolidCube(1);
	glPopMatrix();
}

void animate(int value)
{
	// For Ships Orbitals
	if (orbit >= 360) orbit = 0;
	orbit++;

	// For Cannon Ball
	if (fired) {
		if (by > 5) by -= 0.5;
		if (by > 5) bx += 25;
		if (by <= 5) fired = 0;
		if ((walk_path >= 0 || walk_path >= 355) &&
			walk_path <= 5 && bx >= 500 && bx <= 600) patrol_alive = 0;
		if (fire_arm > 90) fire_arm -= 10;
	}
	else if (!fired) if (fire_arm < 180) fire_arm += 10;


	// For Human-Controlled Robots
	if (cam_mode == 0) {
		rx = eye_x;
		rz = eye_z;
	}

	else {
		rx = free_eyex;
		rz = free_eyez;
	}
	if (p_flag) player += 0.06;
	if (!p_flag) player -= 0.06;
	if (player <= 17) p_flag = 1;
	if (player >= 18) p_flag = 0;

	// Jump feature
	if (jump) {
		if (ry < 8) {
			cam_hgt += 0.5;
			ry += 0.5;
			look_y += 0.5;
		}
		else {
			jump = 0;
		}
	}
	if (jump == 0 && ry > 0) {
		cam_hgt -= 0.5;
		ry -= 0.5;
		look_y -= 0.5;
	}

	// END OF HCR

	// For Robot Patrols
	// walk animation
	if (walk >= 20) walk_flag = 1;
	if (walk <= -20) walk_flag = 0;
	if (!walk_flag) walk += 16;
	if (walk_flag) walk -= 16;
	if (patrol_alive) {
		patrol_walk = walk;
		// walk path
		if (walk_path >= 360) walk_path = 0;
		if (patrol_test && (walk_path >= 1 || walk_path >= 356)
			&& walk_path <= 4) walk_path -= 0.8;
		walk_path += 0.8;
	}

	if (!patrol_alive) {
		if (patrol_fall < 90 && patrol_revive <= 20) patrol_fall += 15;
		if (patrol_dead < 6.5 && patrol_revive <= 20) patrol_dead += 0.5;
		patrol_revive += 0.1;
		if (patrol_revive >= 20) {
			if (patrol_fall > 0) patrol_fall -= 15;
			if (patrol_dead > 0) patrol_dead -= 0.5;
			if (patrol_fall <= 0 && patrol_dead <= 0) {
				patrol_alive = 1;
				patrol_revive = 0;
				//fired = 0;
			}
		}
	}

	// For Robot Workers
	if (!lift && ship_hgt == 0) {
		if (worker_object < 5) worker_object += 0.4;
		if (worker_arms > 60) worker_arms -= 10;
		if (worker_walk == 20) worker_flag = 1;
		if (worker_walk == -20) worker_flag = 0;
		if (!worker_flag) worker_walk += 0.5;
		if (worker_flag) worker_walk -= 0.5;
		if (worker_path >= 360) worker_path = 0;
		worker_path += 0.5;
	}
	else {
		if (worker_object > 2)worker_object -= 0.4;
		if (worker_arms < 180) worker_arms += 6;
	}

	// For ship lift off
	if (lift && ship_hgt <= 600) {
		ship_hgt += 0.8;
		if (cam_mode > 0) {
			cam_hgt += 0.8;
		}
	}
	if (!lift && ship_hgt >= 0) {
		ship_hgt -= 0.8;
		if (cam_mode > 0 && ship_hgt > 0) {
			cam_hgt -= 0.8;
		}
	}
	if (lift && cam_mode == 1 && ship_hgt > 10) {
		eye_x = -50;
		eye_z = 0;
		look_x = -49.99;
		look_z = 0;
		look_y = 0;
		cam_hgt = ship_hgt + 10;
	}
	if (!lift && cam_mode == 1 && ship_hgt <= 0) {
		angle = 0;
		eye_x = -50;
		eye_z = 0;
		look_x = 500;
		look_z = 0;
		look_y = 40;
		cam_hgt = ship_hgt + 80;
	}

	if (ship_hgt < 0) ship_hgt = 0;

	glutPostRedisplay();
}

void display()
{
	//float lpos[4] = { 400., 400., 200., 1.0 };
	float lpos[4] = { 0., 100., 0., 1.0 };

	float spot_pos[] = { 0.0f, 8.0f, -7.0f, 1.0f };
	float spot_dir[] = { 0.0f, -10.0f, -13.0f, 1.0f };
	float hdl_pos[] = { 0.0f, 9.0f, -20.0f, 1.0f };
	float hdl_dir[] = { 0.0f, -10.0f, -15.0f, 1.0f };

	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glTranslatef(0, 0, p_view);
	gluLookAt(eye_x, cam_hgt, eye_z, look_x, look_y, look_z, 0, 1, 0);

	// World Light
	glLightfv(GL_LIGHT0, GL_POSITION, lpos);

	// Skybox
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
	skybox();
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	//glScalef(0.25, 0.25, 0.25);
	drawFloor();

	// Human-Controlled Robot
	glPushMatrix();
	glTranslatef(rx, ry, rz);
	glRotatef(rangle, 0, 1, 0);
	glLightfv(GL_LIGHT2, GL_POSITION, hdl_pos);
	glLightfv(GL_LIGHT2, GL_SPOT_DIRECTION, hdl_dir);
	glScalef(3, 3, 3);
	drawRobot();
	glTranslatef(0, player, 0);
	glRotatef(90, 1, 0, 0);
	glColor3f(0, 1, 0);
	glutSolidCone(1, 4, 10, 6);
	glPopMatrix();
	//glDisable(GL_LIGHT2);

	// Operator Robot (Cannon Operator)
	glPushMatrix();
	glTranslatef(110, 0, -20);
	glRotatef(-90, 0, 1, 0);
	glScalef(3, 3, 3);
	drawRobotOperator();
	glPopMatrix();

	// Patrol Robot
	glPushMatrix();
	glRotatef(walk_path, 0, 1, 0);
	glTranslatef(270, 0, 0);
	glTranslatef(0, patrol_dead, 0);
	glRotatef(-patrol_fall, 0, 0, 1);
	glLightfv(GL_LIGHT1, GL_POSITION, spot_pos);
	glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, spot_dir);
	glScalef(3, 3, 3);
	drawRobotPatrol();
	glPopMatrix();
	glPopMatrix();

	// Worker Robot
	glPushMatrix();
	glTranslatef(10, 0, 13);
	glRotatef(worker_path, 0, 1, 0);
	glTranslatef(10, 0, 0);
	glScalef(3, 3, 3);
	drawRobotWorker();
	glTranslatef(0, worker_object, -2);
	glColor3f(0, 1, 1);
	glutSolidCube(2);
	glPopMatrix();

	// Some Cube stuffs
	glPushMatrix();
	glColor3f(0, 1, 1);
	glTranslatef(25, 3, 30);
	glutSolidCube(6);
	glTranslatef(0, 0, 8);
	glutSolidCube(6);
	glRotatef(25, 0, 1, 0);
	glTranslatef(0, 6, 0);
	glutSolidCube(6);
	glPopMatrix();

	// Environment
	glPushMatrix();
	glScalef(0.6, 0.6, 0.6);
	glColor3f(1., 1., 1.);
	drawWalls();
	glColor3f(1., 1., 1.);
	drawPillars();
	glPopMatrix();

	// Ship
	glPushMatrix();
	glPushMatrix();
	glTranslatef(-50, ship_hgt, 0);
	glRotatef(orbit, 0, 1, 0);
	drawShip();
	glPopMatrix();
	//Shadow
	float shadowShip[16] = { 400,0,0,0, 400,0,-400,-1, 0,0,400,0, 0,0,0,400 };
	glTranslatef(ship_hgt, 0.1, -ship_hgt);
	glMultMatrixf(shadowShip);
	glColor4f(0, 0, 0, 1.0);
	glColor3f(0, 0, 0);
	glDisable(GL_LIGHTING);
	drawShipShadow();
	glEnable(GL_LIGHTING);
	//End
	glPopMatrix();

	// Cannon with shadows
	glPushMatrix();
	glTranslatef(130, 0, -20);
	glScalef(0.25, 0.25, 0.25);
	glRotatef(-5, 0, 1, 0);
	drawCannon();
	float shadowMat[16] = { 400,0,0,0, 400,0,-400,-1, 0,0,400,0, 0,0,0,400 };
	glPushMatrix();
	glTranslatef(0, 1, 0);
	glMultMatrixf(shadowMat);
	glColor4f(0, 0, 0, 1.0);
	glColor3f(0, 0, 0);
	drawCannonShadow();
	glPopMatrix();
	glPopMatrix();

	// General animation loop
	glutTimerFunc(1000 / 60, animate, 0);

    glutSwapBuffers();
	glFlush();
    
}

void initialize()
{
	float grey[4] = { 0.1, 0.1, 0.1, 1.0 };
	float white[4] = { 0.9, 0.9, 0.9, 1.0 };

	loadTexture();
	loadMeshFile("Cannon.off");
	//glClearColor(1.0f, 1.0f, 1.0f, 1.0f);

	glEnable(GL_LIGHTING);

	// World Light
	glEnable(GL_LIGHT0);
	glLightfv(GL_LIGHT0, GL_AMBIENT, grey);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, white);
	glLightfv(GL_LIGHT0, GL_SPECULAR, white);

	// Patrol Light
	glEnable(GL_LIGHT1);
	glLightfv(GL_LIGHT1, GL_AMBIENT, grey);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, white);
	glLightfv(GL_LIGHT1, GL_SPECULAR, white);
	glLightf(GL_LIGHT1, GL_SPOT_CUTOFF, 30.0);
	glLightf(GL_LIGHT1, GL_SPOT_EXPONENT, 0.01);

	// Human-Controlled Robot Light
	glEnable(GL_LIGHT2);
	glLightfv(GL_LIGHT2, GL_AMBIENT, grey);
	glLightfv(GL_LIGHT2, GL_DIFFUSE, white);
	glLightfv(GL_LIGHT2, GL_SPECULAR, white);
	glLightf(GL_LIGHT2, GL_SPOT_CUTOFF, 30.0);
	glLightf(GL_LIGHT2, GL_SPOT_EXPONENT, 0.01);


	glEnable(GL_DEPTH_TEST);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_NORMALIZE);

	glClearColor(0.0, 0.0, 0.0, 0.0);

	glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
	glEnable(GL_COLOR_MATERIAL);

	glMaterialfv(GL_FRONT, GL_SPECULAR, white);
	glMaterialf(GL_FRONT, GL_SHININESS, 50);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60, 1, 10, 2500);
}

void special(int key, int x, int y)
{

	if (key == GLUT_KEY_LEFT && cam_mode != 1) {
		angle -= 0.05;
		if (cam_mode == 0) {
			rangle += 2.8625;
			hcr_walk = walk / 4;
		}
	}
	else if (key == GLUT_KEY_RIGHT && cam_mode != 1) {
		angle += 0.05;
		if (cam_mode == 0) {
			rangle -= 2.8625;
			hcr_walk = walk / 4;
		}
	}
	else if (key == GLUT_KEY_DOWN)
	{  //Move backward
		if (cam_mode == 0) {
			hcr_walk = walk;
			eye_x -= 10 * sin(angle);
			eye_z += 10 * cos(angle);
			if (eye_x >= 550 || eye_x <= -550) eye_x += 10 * sin(angle);
			if (eye_z >= 550 || eye_z <= -550) eye_z -= 10 * cos(angle);
		}
	}
	else if (key == GLUT_KEY_UP)
	{ //Move forward
		if (cam_mode == 0) {
			hcr_walk = walk;
			eye_x += 10 * sin(angle);
			eye_z -= 10 * cos(angle);
			if (eye_x >= 550 || eye_x <= -550) eye_x -= 10 * sin(angle);
			if (eye_z >= 550 || eye_z <= -550) eye_z += 10 * cos(angle);
		}
	}
	else if (key == GLUT_KEY_HOME)
	{
		// Cam mode 1: Ship Camera
		if (cam_mode == 0) {	// Free Camera to Ship Camera 
			p_view = 0;
			// Save current camera state
			free_angle = angle;
			free_eyex = eye_x;
			free_eyez = eye_z;
			free_lookx = look_x;
			free_lookz = look_z;
			free_lookz = look_y;
			free_hgt = cam_hgt;

			if (!lift) {
				angle = 0;
				eye_x = -50;
				eye_z = 0;
				look_x = 500;
				look_z = 0;
				look_y = 40;
				cam_hgt = ship_hgt + 80;
			}
			else if (lift) {
				eye_x = -50;
				eye_z = 0;
				look_x = -49.99;
				look_z = 0;
				look_y = 0;
				cam_hgt = ship_hgt + 10;
			}

			cam_mode = 1;
		}
		// Cam mode 0: Free Camera
		else if (cam_mode == 1) {	// Special Camera to Free Camera
			if (tpv) p_view = -80;
			//Save current camera state

			angle = free_angle;
			eye_x = free_eyex;
			eye_z = free_eyez;
			look_x = free_lookx;
			look_z = free_lookz;
			look_y = free_looky;
			cam_hgt = free_hgt;

			cam_mode = 0;
		}
	}

	look_x = eye_x + 100 * sin(angle);
	look_z = eye_z - 100 * cos(angle);
}

void keyPress(unsigned char key, int x, int y)
{
	if (key == 'c' || key == 'C') {
		if (!fired) {
			bx = 49.88;
			by = 36.5;
			bz = 0;
			fired = 1;
		}
		else if (fired) {
			bx = 49.88;
			by = 36.5;
			bz = 0;
			fired = 0;
		}
	}
	else if ((key == 'a' || key == 'A') && cam_mode == 0)
	{
		if (cam_hgt < 550) {
			cam_hgt += 10;
		}
	}
	else if ((key == 'z' || key == 'Z') && cam_mode == 0)
	{
		if (cam_hgt > 10) {
			cam_hgt -= 10;
		}
	}
	else if (key == 's' || key == 'S') {
		if (!lift) {
			lift = 1;
		}
		else {
			lift = 0;
		}
	}
	else if (key == 32 && cam_mode == 0 && ry == 0) {
		jump = 1;
	}
	else if ((key == 'f' || key == 'F') && cam_mode == 0) {
		if (!p_light) {
			glEnable(GL_LIGHT2);
			p_light = 1;
		}
		else if (p_light) {
			glDisable(GL_LIGHT2);
			p_light = 0;
		}
	}
	else if ((key == 'v' || key == 'V') && cam_mode == 0) {
		if (!tpv) {
			p_view = -80;
			tpv = 1;
		}
		else if (tpv) {
			p_view = 0;
			tpv = 0;
		}
	}
	else if (key == 'p' || key == 'P') {
		if (!patrol_test) patrol_test = 1;
		else if (patrol_test) patrol_test = 0;
	}
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_DEPTH);
	glutInitWindowSize(800, 600);
	glutInitWindowPosition(10, 10);
	glutCreateWindow("Alien Invasion");
	initialize();

	glutDisplayFunc(display);
	glutSpecialFunc(special);
	glutKeyboardFunc(keyPress);
	glutMainLoop();
	return 0;
}
