<?php //config.php
$hostname = "csse-info263.canterbury.ac.nz";
$database = "akl_transport";
$username = "info263";
$password = "info263";
$APIKey = "8c20ae415fb2473f80e96a47c013b94a"; # Your API Key here. #Ariel Auckland API Key: 8c20ae415fb2473f80e96a47c013b94a
?>
